import React from "react";
import { motion } from "framer-motion";

const styles = {
  container: {
    maxWidth: "1200px",
    margin: "0 auto",
    padding: "64px 20px",
    display: "grid",
    gridTemplateColumns: "repeat(4, 1fr)", // Desktop: 4 columns horizontal
    gap: "24px",
    textAlign: "center"
  },
  card: {
    backgroundColor: "#fff",
    boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
    borderRadius: "12px",
    padding: "24px"
  },
  value: {
    fontSize: "2rem",
    fontWeight: "bold",
    color: "#2563eb",
    marginBottom: "8px"
  },
  label: {
    color: "#6b7280",
    fontSize: "1rem"
  }
};

// Media query for mobile
const containerMobile = {
  display: "grid",
  gridTemplateColumns: "1fr",
  gap: "24px",
  textAlign: "center",
  padding: "64px 20px"
};

function Stats() {
  const stats = [
    { label: "Patients", value: "10K+" },
    { label: "Tests", value: "500+" },
    { label: "Doctors", value: "25+" },
    { label: "Experience", value: "15 Years" }
  ];

  // Detect screen width
  const isMobile = window.innerWidth < 768;

  return (
    <div style={isMobile ? containerMobile : styles.container}>
      {stats.map((s, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          style={styles.card}
        >
          <h2 style={styles.value}>{s.value}</h2>
          <p style={styles.label}>{s.label}</p>
        </motion.div>
      ))}
    </div>
  );
}

export default Stats;