import React from "react";

const styles = {
  container: {
    maxWidth: "1200px",
    margin: "0 auto",
    padding: "64px 20px"
  },
  title: {
    fontSize: "2rem",
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: "40px"
  },
  grid: {
    display: "grid",
    gridTemplateColumns: "repeat(3, 1fr)", // Desktop: 3 columns horizontal
    gap: "24px"
  },
  card: {
    textAlign: "center",
    backgroundColor: "#fff",
    boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
    borderRadius: "12px",
    padding: "24px"
  },
  img: {
    width: "128px",
    height: "128px",
    objectFit: "cover",
    borderRadius: "50%",
    margin: "0 auto 16px"
  },
  name: {
    fontWeight: "600",
    fontSize: "1.2rem",
    marginBottom: "8px"
  },
  role: {
    color: "#6b7280",
    fontSize: "1rem"
  }
};

// Mobile adjustment: 1 column on small screens
const gridMobile = {
  display: "grid",
  gridTemplateColumns: "1fr",
  gap: "24px"
};

function Doctors() {
  const docs = [
    { name: "Dr. Sharma", img: "https://randomuser.me/api/portraits/men/32.jpg" },
    { name: "Dr. Mehta", img: "https://randomuser.me/api/portraits/women/44.jpg" },
    { name: "Dr. Khan", img: "https://randomuser.me/api/portraits/men/76.jpg" }
  ];

  const isMobile = window.innerWidth < 768;

  return (
    <div style={styles.container}>
      <h2 style={styles.title}>Our Specialists</h2>
      <div style={isMobile ? gridMobile : styles.grid}>
        {docs.map((d, i) => (
          <div key={i} style={styles.card}>
            <img src={d.img} alt={d.name} style={styles.img} />
            <h3 style={styles.name}>{d.name}</h3>
            <p style={styles.role}>Senior Specialist</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Doctors;