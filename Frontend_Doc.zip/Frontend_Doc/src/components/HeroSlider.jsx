import React, { useState, useEffect } from "react";

const heroImages = [
  "https://images.unsplash.com/photo-1581595219315-a187dd40c322",
  "https://images.unsplash.com/photo-1576091160550-2173dba999ef",
  "https://images.unsplash.com/photo-1582750433449-648ed127bb54"
];

const styles = {
  slider: {
    position: "relative",
    width: "100%",
    height: "70vh",
    overflow: "hidden",
    backgroundColor: "#f3f3f3"
  },
  img: {
    position: "absolute",
    width: "100%",
    height: "100%",
    objectFit: "cover",
    transition: "opacity 0.7s ease-in-out"
  },
  overlay: {
    position: "absolute",
    inset: 0,
    backgroundColor: "rgba(0,0,0,0.4)",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    textAlign: "center",
    padding: "0 20px"
  },
  title: {
    fontSize: "2.5rem",
    fontWeight: "bold",
    color: "#fff",
    marginBottom: "1rem"
  },
  desc: {
    color: "#fff",
    fontSize: "1.1rem",
    marginBottom: "1.5rem"
  },
  btn: {
    backgroundColor: "#2563eb",
    color: "#fff",
    padding: "12px 30px",
    border: "none",
    borderRadius: "6px",
    cursor: "pointer",
    fontSize: "1rem"
  }
};

function HeroSlider() {
  const [index, setIndex] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setIndex((prev) => (prev + 1) % heroImages.length);
    }, 4000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div style={styles.slider}>
      {heroImages.map((img, i) => (
        <img
          key={i}
          src={img}
          alt={`slide-${i}`}
          style={{
            ...styles.img,
            opacity: i === index ? 1 : 0
          }}
        />
      ))}

      <div style={styles.overlay}>
        <div>
          <h1 style={styles.title}>Advanced Diagnostic Laboratory</h1>
          <p style={styles.desc}>
            Accurate testing. Trusted results. Better health for everyone.
          </p>
          <button style={styles.btn}>Book Appointment</button>
        </div>
      </div>
    </div>
  );
}

export default HeroSlider;