import React from "react";

const styles = {
  footer: {
    backgroundColor: "#111827", // bg-gray-900
    color: "#fff",
    marginTop: "64px",
    paddingTop: "40px",
    paddingBottom: "20px"
  },
  container: {
    maxWidth: "1200px",
    margin: "0 auto",
    display: "grid",
    gridTemplateColumns: "repeat(3, 1fr)", // Desktop: 3 columns
    gap: "32px",
    padding: "0 24px"
  },
  heading: {
    fontSize: "1.25rem",
    fontWeight: "600",
    marginBottom: "8px"
  },
  text: {
    color: "#9ca3af", // gray-400
    marginBottom: "6px",
    fontSize: "0.95rem"
  },
  list: {
    listStyle: "none",
    padding: 0,
    margin: 0
  },
  listItem: {
    color: "#9ca3af",
    marginBottom: "6px",
    cursor: "pointer"
  },
  centerText: {
    textAlign: "center",
    color: "#9ca3af",
    paddingTop: "24px",
    fontSize: "0.9rem"
  }
};

// Mobile adjustments: 1 column
const containerMobile = {
  display: "grid",
  gridTemplateColumns: "1fr",
  gap: "32px",
  padding: "0 24px"
};

function Footer() {
  const isMobile = window.innerWidth < 768;

  return (
    <footer style={styles.footer}>
      <div style={isMobile ? containerMobile : styles.container}>
        <div>
          <h2 style={styles.heading}>HealthLab</h2>
          <p style={styles.text}>
            Trusted diagnostic laboratory providing accurate reports and
            advanced health testing.
          </p>
        </div>

        <div>
          <h2 style={styles.heading}>Quick Links</h2>
          <ul style={styles.list}>
            {["Services", "Health Packages", "Report Download", "Appointment"].map(
              (link, i) => (
                <li key={i} style={styles.listItem}>
                  {link}
                </li>
              )
            )}
          </ul>
        </div>

        <div>
          <h2 style={styles.heading}>Contact</h2>
          <p style={styles.text}>Phone: +91 9000000000</p>
          <p style={styles.text}>Email: info@healthlab.com</p>
        </div>
      </div>

      <div style={styles.centerText}>© 2026 HealthLab Diagnostic</div>
    </footer>
  );
}

export default Footer;