import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";

const styles = {
  nav: {
    backgroundColor: "#fff",
    boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
    position: "sticky",
    top: 0,
    zIndex: 1000
  },
  container: {
    maxWidth: "1200px",
    margin: "0 auto",
    padding: "12px 20px",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center"
  },
  brand: {
    fontSize: "1.8rem",
    fontWeight: "bold",
    color: "#2563eb"
  },
  btn: {
    fontSize: "1.8rem",
    display: "block",
    background: "none",
    border: "none",
    cursor: "pointer"
  },
  menu: {
    display: "flex",
    gap: "20px",
    fontWeight: 500
  },
  link: (active) => ({
    textDecoration: "none",
    padding: "6px 12px",
    borderRadius: "6px",
    color: active ? "#2563eb" : "#374151",
    fontWeight: active ? 600 : 500,
    transition: "color 0.3s"
  }),
  mobileMenu: {
    display: "flex",
    flexDirection: "column",
    padding: "12px 20px",
    gap: "10px"
  }
};

function Navbar() {
  const [open, setOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
  const location = useLocation();

  // Track window resize
  useEffect(() => {
    const handleResize = () => setIsMobile(window.innerWidth < 768);
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const navItem = (to, label) => (
    <Link
      key={to}
      to={to}
      style={styles.link(location.pathname === to)}
      onClick={() => setOpen(false)}
    >
      {label}
    </Link>
  );

  return (
    <nav style={styles.nav}>
      <div style={styles.container}>
        <h1 style={styles.brand}>HealthLab</h1>

        {/* Hamburger button for mobile */}
        {isMobile && (
          <button style={styles.btn} onClick={() => setOpen(!open)}>
            ☰
          </button>
        )}

        {/* Desktop Menu */}
        {!isMobile && <div style={styles.menu}>
          {navItem("/", "Home")}
          {navItem("/services", "Services")}
          {navItem("/packages", "Health Packages")}
          {navItem("/appointment", "Appointment")}
          {navItem("/report", "Report Download")}
          {navItem("/contact", "Contact")}
        </div>}
      </div>

      {/* Mobile Menu */}
      {isMobile && open && (
        <div style={styles.mobileMenu}>
          {navItem("/", "Home")}
          {navItem("/services", "Services")}
          {navItem("/packages", "Health Packages")}
          {navItem("/appointment", "Appointment")}
          {navItem("/report", "Report Download")}
          {navItem("/contact", "Contact")}
        </div>
      )}
    </nav>
  );
}

export default Navbar;