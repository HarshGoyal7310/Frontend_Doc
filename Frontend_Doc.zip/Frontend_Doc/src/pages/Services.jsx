import React from "react";

const styles = {
  heroContainer: {
    width: "100%",
    position: "relative"
  },
  heroImage: {
    width: "100%",
    height: "60vh", // hero height
    objectFit: "cover", // image full section cover kare
    display: "block"
  },
  heroTitle: {
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    color: "#fff",
    fontSize: "3rem",
    fontWeight: "bold",
    textAlign: "center",
    margin: 0,
    padding: "0 20px"
  },
  container: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))",
    gap: "20px",
    padding: "20px",
    width: "100%",
    maxWidth: "1400px",
    margin: "0 auto"
  },
  card: {
    backgroundColor: "#fff",
    boxShadow: "0 4px 10px rgba(0,0,0,0.1)",
    borderRadius: "12px",
    padding: "20px",
    textAlign: "center",
    transition: "all 0.3s",
    cursor: "pointer",
    display: "flex",
    flexDirection: "column",
    alignItems: "center"
  },
  cardTitle: {
    fontSize: "1.25rem",
    fontWeight: "600",
    marginBottom: "10px"
  },
  cardDesc: {
    color: "#6b7280"
  }
};

function Services() {
  const services = [
    "Blood Testing",
    "X-Ray",
    "MRI Scan",
    "CT Scan",
    "Pathology",
    "Ultrasound",
    "ECG",
    "Echocardiogram",
    "Blood Sugar Test",
    "Liver Function Test"
  ];

  return (
    <>
      {/* Hero Section with image */}
      <div style={styles.heroContainer}>
        <img
          src="https://images.unsplash.com/photo-1579684453423-f84349ef60b0"
          alt="Hero"
          style={styles.heroImage}
        />
        <h1 style={styles.heroTitle}>Our Services</h1>
      </div>

      {/* Services Cards */}
      <div style={styles.container}>
        {services.map((s, i) => (
          <div
            key={i}
            style={styles.card}
            onMouseEnter={(e) =>
              (e.currentTarget.style.boxShadow = "0 8px 20px rgba(0,0,0,0.15)")
            }
            onMouseLeave={(e) =>
              (e.currentTarget.style.boxShadow = "0 4px 10px rgba(0,0,0,0.1)")
            }
          >
            <h3 style={styles.cardTitle}>{s}</h3>
            <p style={styles.cardDesc}>High quality diagnostic service.</p>
          </div>
        ))}
      </div>
    </>
  );
}

export default Services;