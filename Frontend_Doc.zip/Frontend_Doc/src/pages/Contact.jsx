import React from "react";
import "./Contact.css"; // ye CSS file create karni hogi

function Contact() {
  return (
    <>
      {/* Hero Section */}
      <div className="hero">
        <h1 className="hero-title">Contact Us</h1>
      </div>

      {/* Form Section */}
      <div className="container">
        <img
          src="https://images.unsplash.com/photo-1584432810601-6c7f27d2362b"
          alt="Doctor Contact"
          className="contact-img"
        />

        <form className="form">
          <input type="text" placeholder="Your Name" className="input" />
          <input type="email" placeholder="Email" className="input" />
          <textarea placeholder="Your Problem" className="textarea"></textarea>
          <button className="btn">Send Message</button>
        </form>
      </div>
    </>
  );
}

export default Contact;