import React from "react";
import HeroSlider from "../components/HeroSlider";
import Stats from "../components/Stats";
import Doctors from "../components/Doctors";

const styles = {
  container: {
    maxWidth: "1200px",
    margin: "0 auto",
    padding: "64px 20px"
  },
  cards: {
    display: "grid",
    gridTemplateColumns: "repeat(3, 1fr)", // Desktop: 3 cards horizontal
    gap: "24px"
  },
  card: {
    backgroundColor: "#fff",
    boxShadow: "0 4px 12px rgba(0,0,0,0.1)",
    borderRadius: "12px",
    padding: "24px",
    transition: "all 0.3s",
    cursor: "pointer"
  },
  cardTitle: {
    fontSize: "1.25rem",
    fontWeight: "600",
    marginBottom: "8px"
  },
  cardDesc: {
    color: "#6b7280",
    fontSize: "1rem"
  },
  cardsMobile: {
    display: "grid",
    gridTemplateColumns: "1fr",
    gap: "24px"
  }
};

function Home() {
  const isMobile = window.innerWidth < 768;

  const services = [
    "Blood Test",
    "Full Body Checkup",
    "Home Sample Collection"
  ];

  return (
    <>
      <HeroSlider />
      <Stats />
      <Doctors />
      <div style={styles.container}>
        <div style={isMobile ? styles.cardsMobile : styles.cards}>
          {services.map((s, i) => (
            <div
              key={i}
              style={{
                ...styles.card,
                ...(isMobile ? { width: "100%" } : {})
              }}
              onMouseEnter={(e) =>
                (e.currentTarget.style.boxShadow = "0 8px 24px rgba(0,0,0,0.2)")
              }
              onMouseLeave={(e) =>
                (e.currentTarget.style.boxShadow = "0 4px 12px rgba(0,0,0,0.1)")
              }
            >
              <h3 style={styles.cardTitle}>{s}</h3>
              <p style={styles.cardDesc}>
                Professional lab testing with accurate reports.
              </p>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

export default Home;