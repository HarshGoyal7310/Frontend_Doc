import React, { useState } from "react";
import "./Report.css"; // CSS file create karenge

function Report() {
  const [phone, setPhone] = useState("");
  const [labId, setLabId] = useState("");
  const [preview, setPreview] = useState(null);

  const handleSearch = (e) => {
    e.preventDefault();
    if (phone && labId) {
      setPreview({
        title: "Sample Report Preview",
        desc: `Blood Test Report - Patient: ${phone}`
      });
    } else {
      setPreview(null);
      alert("Please enter Phone Number and Lab ID");
    }
  };

  return (
    <>
      {/* Hero Section */}
      <div className="hero">
        <img
          src="https://images.unsplash.com/photo-1582719478250-c89cae4dc85b"
          alt="Medical Report"
          className="hero-img"
        />
        <h1 className="hero-title">Download Report</h1>
      </div>

      {/* Form Section */}
      <div className="container">
        <form onSubmit={handleSearch} className="form">
          <input
            type="text"
            placeholder="Phone Number"
            className="input"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
          />
          <input
            type="text"
            placeholder="Lab ID"
            className="input"
            value={labId}
            onChange={(e) => setLabId(e.target.value)}
          />
          <button type="submit" className="btn">
            Search Report
          </button>
        </form>

        {/* Preview Section */}
        {preview && (
          <div className="report">
            <h3 className="report-title">{preview.title}</h3>
            <p className="report-desc">{preview.desc}</p>
            <button className="download-btn">Download</button>
          </div>
        )}
      </div>
    </>
  );
}

export default Report;