import React from "react";

const styles = {
  heroContainer: {
    width: "100%",
    position: "relative"
  },
  heroImage: {
    width: "100%",
    height: "50vh",
    objectFit: "cover",
    display: "block"
  },
  heroTitle: {
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    color: "#fff",
    fontSize: "3rem",
    fontWeight: "bold",
    textAlign: "center",
    margin: 0,
    padding: "0 20px"
  },
  container: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))",
    gap: "20px",
    padding: "40px 20px",
    maxWidth: "1400px",
    margin: "0 auto"
  },
  card: {
    backgroundColor: "#fff",
    boxShadow: "0 4px 15px rgba(0,0,0,0.1)",
    borderRadius: "12px",
    overflow: "hidden",
    display: "flex",
    flexDirection: "column",
    cursor: "pointer",
    transition: "all 0.3s"
  },
  img: {
    width: "100%",
    height: "200px",
    objectFit: "cover"
  },
  content: {
    padding: "16px"
  },
  name: {
    fontSize: "1.25rem",
    fontWeight: 600
  },
  price: {
    color: "#2563eb",
    fontWeight: "bold",
    marginTop: "8px"
  },
  btn: {
    marginTop: "12px",
    backgroundColor: "#2563eb",
    color: "#fff",
    padding: "8px 16px",
    borderRadius: "6px",
    border: "none",
    cursor: "pointer",
    transition: "background-color 0.3s"
  }
};

function Packages() {
  const packages = [
    {
      name: "Basic Health Package",
      price: "1500",
      img: "https://images.unsplash.com/photo-1579684385127-1ef15d508118"
    },
    {
      name: "Preventive Health Package",
      price: "2000",
      img: "https://images.unsplash.com/photo-1580281657527-47e7d11b5c79"
    },
    {
      name: "Smart Body Package",
      price: "3000",
      img: "https://images.unsplash.com/photo-1584982751601-97dcc096659c"
    },
    {
      name: "Overall Wellbeing Package",
      price: "3000",
      img: "https://images.unsplash.com/photo-1559757175-7b21e9c4c2f8"
    }
  ];

  return (
    <>
      {/* Hero Section */}
      <div style={styles.heroContainer}>
        <img
          src="https://images.unsplash.com/photo-1581594693702-fbdc51b2763b"
          alt="Hero"
          style={styles.heroImage}
        />
        <h1 style={styles.heroTitle}>Health Packages</h1>
      </div>

      {/* Packages Cards */}
      <div style={styles.container}>
        {packages.map((p, i) => (
          <div
            key={i}
            style={styles.card}
            onMouseEnter={(e) =>
              (e.currentTarget.style.boxShadow = "0 8px 20px rgba(0,0,0,0.2)")
            }
            onMouseLeave={(e) =>
              (e.currentTarget.style.boxShadow = "0 4px 15px rgba(0,0,0,0.1)")
            }
          >
            <img src={p.img} style={styles.img} alt={p.name} />
            <div style={styles.content}>
              <h3 style={styles.name}>{p.name}</h3>
              <p style={styles.price}>Rs. {p.price}</p>
              <button style={styles.btn}>Apply Now</button>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}

export default Packages;