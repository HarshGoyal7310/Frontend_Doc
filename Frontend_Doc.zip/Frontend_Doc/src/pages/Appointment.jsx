import React from "react";

const styles = {
  heroContainer: {
    width: "100%",
    position: "relative"
  },
  heroImage: {
    width: "100%",
    height: "50vh",
    objectFit: "cover",
    display: "block"
  },
  heroTitle: {
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    color: "#fff",
    fontSize: "3rem",
    fontWeight: "bold",
    textAlign: "center",
    margin: 0,
    padding: "0 20px"
  },
  container: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))",
    gap: "40px",
    padding: "40px 20px",
    maxWidth: "1200px",
    margin: "0 auto",
    alignItems: "center"
  },
  img: {
    width: "100%",
    borderRadius: "12px",
    boxShadow: "0 4px 20px rgba(0,0,0,0.1)",
    objectFit: "cover"
  },
  form: {
    backgroundColor: "#fff",
    boxShadow: "0 4px 15px rgba(0,0,0,0.1)",
    padding: "30px",
    borderRadius: "12px",
    display: "flex",
    flexDirection: "column",
    gap: "16px"
  },
  input: {
    padding: "12px",
    borderRadius: "6px",
    border: "1px solid #ccc",
    width: "100%"
  },
  btn: {
    padding: "12px",
    borderRadius: "6px",
    border: "none",
    backgroundColor: "#2563eb",
    color: "#fff",
    fontWeight: "bold",
    cursor: "pointer",
    transition: "background-color 0.3s"
  }
};

function Appointment() {
  return (
    <>
      {/* Hero Section */}
      <div style={styles.heroContainer}>
        <img
          src="https://images.unsplash.com/photo-1579684453423-f84349ef60b0"
          alt="Appointment Hero"
          style={styles.heroImage}
        />
        <h1 style={styles.heroTitle}>Book Appointment</h1>
      </div>

      {/* Image + Form Section */}
      <div style={styles.container}>
        <img
          src="https://images.unsplash.com/photo-1580281658629-8c05f9d36f6c"
          alt="Doctor/Patient"
          style={styles.img}
        />

        <form style={styles.form}>
          <input placeholder="Patient Name" style={styles.input} />
          <input placeholder="Phone Number" style={styles.input} />
          <button type="submit" style={styles.btn}>Book Now</button>
        </form>
      </div>
    </>
  );
}

export default Appointment;